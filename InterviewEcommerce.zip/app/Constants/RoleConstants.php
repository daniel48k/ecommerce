<?php

namespace App\Constants;

class RoleConstants
{
    public const CLIENT=1;
    public const ADMIN=2;
}
